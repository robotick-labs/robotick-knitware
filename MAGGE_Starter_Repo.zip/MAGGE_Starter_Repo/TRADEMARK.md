# Trademark Notice: MAGG.e™

- "MAGG.e" and the MAGG.e character design (including knitted appearance and visual likeness) are trademarks of Paul Connor.
- You may not use the MAGG.e name or likeness in commercial products, marketing, or derivative robots without explicit permission.
- The code and design files in this repository are licensed under Apache 2.0, but the brand identity is protected separately.

For commercial inquiries, please contact the project maintainers.
