# Contributing to MAGG.e

Thank you for your interest! Contributions are welcome via pull requests.

This project uses the Apache 2.0 license. Please ensure any contributions respect:
- Licensing (see LICENSE)
- Trademark restrictions (see TRADEMARK.md)
- Project structure and code style

See issues for good starting tasks!
